#azure-iot-http-base
Internal library of HTTP-specific components shared between the Azure IoT device and service SDKs.

[![npm version](https://badge.fury.io/js/azure-iot-http-base.svg)](https://badge.fury.io/js/azure-iot-http-base)

NOTE: You generally don't want to reference this package directly. The HTTP components you need should be exposed by packages in the device (`azure-iot-device-http`) or service (`azure-iothub`) SDKs.