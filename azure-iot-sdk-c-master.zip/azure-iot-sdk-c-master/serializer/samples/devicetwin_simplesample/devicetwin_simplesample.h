// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef DEVICETWIN_SIMPLESAMPLE_H
#define DEVICETWIN_SIMPLESAMPLE_H

#ifdef __cplusplus
extern "C" {
#endif

    void device_twin_simple_sample_run(void);

#ifdef __cplusplus
}
#endif

#endif /* DEVICETWIN_SIMPLESAMPLE_H */
