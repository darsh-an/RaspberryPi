# To build the sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).

In addition to the libraries to be imported from the link above, the following libraries need to be imported:

https://developer.mbed.org/users/chris/code/C12832/ 
https://developer.mbed.org/users/neilt6/code/LM75B/
