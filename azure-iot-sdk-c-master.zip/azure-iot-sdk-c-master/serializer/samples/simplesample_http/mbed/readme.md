# To build the simplesample_amqp sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).