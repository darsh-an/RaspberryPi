# To build the simplesample_amqp sample

Follow the instructions [here](https://github.com/Azure/azure-iot-sdks/blob/master/c/doc/devbox_setup.md).