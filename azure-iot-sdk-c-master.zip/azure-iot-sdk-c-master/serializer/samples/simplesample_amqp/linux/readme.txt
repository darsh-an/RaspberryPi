# To build the sample

Follow the instructions [here](https://github.com/Azure/azure-iot-sdks/blob/master/doc/get_started/linux-desktop-c.md).
