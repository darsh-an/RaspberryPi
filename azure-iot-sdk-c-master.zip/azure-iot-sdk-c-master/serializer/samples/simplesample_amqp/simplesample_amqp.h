// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef SIMPLESAMPLEAMQP_H
#define SIMPLESAMPLEAMQP_H

#ifdef __cplusplus
extern "C" {
#endif

    void simplesample_amqp_run(void);

#ifdef __cplusplus
}
#endif

#endif /* SIMPLESAMPLEAMQP_H */
