# To build the iothub_client_sample_device_method sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).