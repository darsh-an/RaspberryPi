// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define COMPILING_REAL_CONSTBUFFER_C

#define GBALLOC_H

#include "real_constbuffer.h"

#include "constbuffer.c"
