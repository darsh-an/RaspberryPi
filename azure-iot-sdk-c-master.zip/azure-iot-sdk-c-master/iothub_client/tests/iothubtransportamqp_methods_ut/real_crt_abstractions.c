// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define mallocAndStrcpy_s real_mallocAndStrcpy_s
#define unsignedIntToString real_unsignedIntToString
#define size_tToString real_size_tToString

#define GBALLOC_H

#include "crt_abstractions.c"
