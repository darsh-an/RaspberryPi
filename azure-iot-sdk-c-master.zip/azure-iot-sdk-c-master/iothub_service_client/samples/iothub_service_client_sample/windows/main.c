// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "iothub_service_client_sample.h"

int main(void)
{
	iothub_service_client_sample_run();
    return 0;
}
