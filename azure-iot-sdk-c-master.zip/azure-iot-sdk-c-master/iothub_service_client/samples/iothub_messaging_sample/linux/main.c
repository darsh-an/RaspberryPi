// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include "iothub_messaging_sample.h"

int main(void)
{
    iothub_messaging_sample_run();
	return 0;
}
